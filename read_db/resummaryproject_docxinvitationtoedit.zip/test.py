from func import get_alpha, get_radius, get_area
from fp import fixed_point
import MySQLdb

## Database Config. 
dbhost = '10.11.17.1'
dbuser = 'root'
dbpwd = 'password'
dbname = 'fgreproject'
##############

#lst_p = [-50, -56, -47, -48]
#lst_r = [(100, 200), (700, 200), (100, 560), (700, 560)]

#powers = [-90, -100, -80, 70]

#print get_area(lst_p, lst_r)
#print fixed_point("zotach1")

# Connect to database and dump data 
def run_query(dbhost, dbuser, dbpass, dbname, query):
    # connect to MySQL
    conn = MySQLdb.connect(host= dbhost,
                      user=dbuser,
                      passwd=dbpass,
                      db=dbname)
    x = conn.cursor()

    try:
        result = x.execute(query)
        conn.commit()
    except:
       conn.rollback()

    #close connection   
    conn.close()
    return result

query = "SELECT ssid, session_id, rssi, timestamp, robot_id, loc_x, loc_y from rssi_values"
run_query(dbhost, dbuser, dbpwd, dbname, query)
